#GROUP 7

library(tidyr)
library(ggplot2)

#Data Read--------------------------------------------------
raw_data <- read.csv("C:/Users/AKSHAT/Downloads/final.csv")
#-----------------------------------------------------------

#Removing outliers and NA Values-------------------------
Fever_data <- subset(raw_data,v45 <= 33.7)
Fever_data <- Fever_data[!is.na(Fever_data$gdp), ]
Fever_data <- Fever_data[!is.na(Fever_data$tap), ]
Fever_data <- Fever_data[!is.na(Fever_data$beds), ]
Fever_data <- Fever_data[!is.na(Fever_data$index), ]
Fever_data <- Fever_data[!is.na(Fever_data$v30), ]
Fever_data <- Fever_data[!is.na(Fever_data$v28), ]
Fever_data <- Fever_data[!is.na(Fever_data$v4), ]
Fever_data <- Fever_data[!is.na(Fever_data$WQI), ]
#---------------------------------------------------------

#Removing 0 values for log------------------
Fever_data <- subset(Fever_data,gdp!=0)
Fever_data <- subset(Fever_data,beds!=0)
Fever_data <- subset(Fever_data,tap!=0)
Fever_data <- subset(Fever_data,v4!=0)
Fever_data <- subset(Fever_data,WQI!=0)

#-------------------------------------------

#Dividing into Rabi and Kharif---------------------
rabi_data <- subset(Fever_data,season=="Rabi")
kharif_data <- subset(Fever_data,season=="Kharif")
#--------------------------------------------------

#Removing duplicate values across SDYID-----------------------
rabi_data <- rabi_data[!duplicated(rabi_data$sd_cc_syid),]
kharif_data <- kharif_data[!duplicated(kharif_data$sd_cc_syid),]
#-------------------------------------------------------------

#QUESTION 1

#FINAL Models-------------------------------------------------------------------------------------------
model_rabi <- lm(v45 ~ index+log(gdp) + log(tap) + log(beds) + v30 + v28 + log(v4) + log(WQI) , rabi_data)
summary(model_rabi)

model_kharif <- lm(v45 ~ index+ log(gdp) + log(tap) + log(beds) + v30 + v28 + log(v4) + log(WQI), kharif_data)
summary(model_kharif)
#----------------------------------------------------------------------------------------------------------

#FINDING RESIDUALS AND U_HATS-----------------------
u_hat_rabi <- residuals(model_rabi)
rabi_data$u_hat <- u_hat_rabi

u_hat_kharif<- residuals(model_kharif)
kharif_data$u_hat <- u_hat_kharif

y_hat_rabi <- fitted(model_rabi)
rabi_data$y_hat <- y_hat_rabi

y_hat_kharif <- fitted(model_kharif)
kharif_data$y_hat <- y_hat_kharif

rabi_data$x1u <- rabi_data$index*u_hat_rabi
rabi_data$x2u <- rabi_data$gdp*u_hat_rabi
rabi_data$x3u <- rabi_data$tap*u_hat_rabi
rabi_data$x4u <- rabi_data$beds*u_hat_rabi
rabi_data$x5u <- rabi_data$v30*u_hat_rabi
rabi_data$x6u <- rabi_data$v28*u_hat_rabi
rabi_data$x7u <- rabi_data$v4*u_hat_rabi
rabi_data$x8u <- rabi_data$WQI*u_hat_rabi

kharif_data$x1u <- kharif_data$index*u_hat_kharif
kharif_data$x2u <- kharif_data$gdp*u_hat_kharif
kharif_data$x3u <- kharif_data$tap*u_hat_kharif
kharif_data$x4u <- kharif_data$beds*u_hat_kharif
kharif_data$x5u <- kharif_data$v30*u_hat_kharif
kharif_data$x6u <- kharif_data$v28*u_hat_kharif
kharif_data$x7u <- kharif_data$v4*u_hat_kharif
kharif_data$x8u <- kharif_data$WQI*u_hat_kharif
#------------------------------------------------------



#PLOTS--------------------------------------------------------------------------------------------------------
ggplot(data = rabi_data, aes(x = index, y = v45)) + geom_point(color='black') + geom_smooth(method = "lm",se = FALSE)

ggplot(data = rabi_data, mapping = aes(x = index, y = u_hat_rabi))+geom_point()

ggplot(data = rabi_data, mapping = aes(x = v45, y = y_hat_rabi))+geom_point() + xlim(0,30) + ylim(0,30)



ggplot(data = kharif_data, aes(x = index, y = v45)) + geom_point(color='black') + geom_smooth(method = "lm",se = FALSE)

ggplot(data = kharif_data, mapping = aes(x = index, y = u_hat_kharif))+geom_point()

ggplot(data = kharif_data, mapping = aes(x = v45, y = y_hat_kharif))+geom_point() + xlim(0,30) + ylim(0,30)

#-------------------------------------------------------------------------------------------------------------

#HISTOGRAMS-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
ggplot(rabi_data, aes(x = rabi_data$u_hat))+geom_histogram(binwidth=2,color="black", fill="white")+ geom_vline(aes(xintercept=mean(rabi_data$u_hat)),color="blue", linetype="dashed", size=1)

ggplot(rabi_data, aes(x = rabi_data$x1u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(rabi_data$x1u)),color="blue", linetype="dashed", size=1)
ggplot(rabi_data, aes(x = rabi_data$x2u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(rabi_data$x2u)),color="blue", linetype="dashed", size=1)
ggplot(rabi_data, aes(x = rabi_data$x3u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(rabi_data$x3u)),color="blue", linetype="dashed", size=1)
ggplot(rabi_data, aes(x = rabi_data$x4u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(rabi_data$x4u)),color="blue", linetype="dashed", size=1)
ggplot(rabi_data, aes(x = rabi_data$x5u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(rabi_data$x5u)),color="blue", linetype="dashed", size=1)
ggplot(rabi_data, aes(x = rabi_data$x6u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(rabi_data$x6u)),color="blue", linetype="dashed", size=1)
ggplot(rabi_data, aes(x = rabi_data$x7u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(rabi_data$x7u)),color="blue", linetype="dashed", size=1)
ggplot(rabi_data, aes(x = rabi_data$x8u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(rabi_data$x8u)),color="blue", linetype="dashed", size=1)


ggplot(kharif_data, aes(x = kharif_data$u_hat))+geom_histogram(binwidth=2,color="black", fill="white")+ geom_vline(aes(xintercept=mean(kharif_data$u_hat)),color="blue", linetype="dashed", size=1)

ggplot(kharif_data, aes(x = kharif_data$x1u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(kharif_data$x1u)),color="blue", linetype="dashed", size=1)
ggplot(kharif_data, aes(x = kharif_data$x2u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(kharif_data$x2u)),color="blue", linetype="dashed", size=1)
ggplot(kharif_data, aes(x = kharif_data$x3u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(kharif_data$x3u)),color="blue", linetype="dashed", size=1)
ggplot(kharif_data, aes(x = kharif_data$x4u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(kharif_data$x4u)),color="blue", linetype="dashed", size=1)
ggplot(kharif_data, aes(x = kharif_data$x5u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(kharif_data$x5u)),color="blue", linetype="dashed", size=1)
ggplot(kharif_data, aes(x = kharif_data$x6u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(kharif_data$x6u)),color="blue", linetype="dashed", size=1)
ggplot(kharif_data, aes(x = kharif_data$x7u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(kharif_data$x7u)),color="blue", linetype="dashed", size=1)
ggplot(kharif_data, aes(x = kharif_data$x8u))+geom_histogram(bins = 50,color="black", fill="white")+ geom_vline(aes(xintercept=mean(kharif_data$x8u)),color="blue", linetype="dashed", size=1)
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


#QUESTION 2------------------------------------------------------------------
mc_simulator <- function(data,count){
  modeltrue <- lm(v45 ~ index, data)
  all_coefficient <- summary(modeltrue)$coefficients
  true_B0<- all_coefficient[1,1]
  true_B1 <- all_coefficient[2,1]
  
  B0_sum <- 0
  B1_sum <- 0
  for (x in 1:count) {
    sub_sample <- data[-sample(1:nrow(data), 20*(nrow(data)/100)), ]
    temp_model <- lm(v45 ~ index, sub_sample)
    all <- summary(temp_model)$coefficients
    temp_B0<- all[1,1]
    temp_B1 <- all[2,1]
    B0_sum <- B0_sum + temp_B0
    B1_sum <- B1_sum + temp_B1
  }
  calc_B0 = B0_sum/count
  calc_B1 = B1_sum/count
  print(paste("True B0 ->",true_B0))
  print(paste("Calc B0 ->",calc_B0))
  print(paste("Difference in B0 ->",true_B0 - calc_B0))
  
  print(paste("True B1 ->",true_B1))
  print(paste("Calc B1 ->",calc_B1))
  print(paste("Difference in B1 ->",true_B1 - calc_B1))
}

mc_simulator(rabi_data,1000)
mc_simulator(kharif_data,1000)
#-----------------------------------------------------------------------------

#Question 3

#Adding Dummy Variables and running T-tests--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
model_rabi <- lm(v45 ~ index+log(gdp) + log(tap) + log(beds) + v30 + v28 + log(v4) + log(WQI) , rabi_data)
summary(model_rabi)

datarabi <- transform(rabi_data, dsouth = ifelse(rabi_data$state == "Andhra Pradesh" | rabi_data$state == "Telangana" | rabi_data$state =="Karnataka" | rabi_data$state == "Kerala" | rabi_data$state == "Tamil Nadu",1,0))
model_south_rabi <- lm(v45 ~ index+log(gdp) + log(tap) + log(beds) + v30 + v28 + log(v4) + log(WQI) + dsouth, datarabi)
summary(model_south_rabi)

datarabi <- transform(rabi_data, dnorth = ifelse(rabi_data$state=="Bihar" | rabi_data$state=="Orissa" | rabi_data$state=="Jharkhand" | rabi_data$state=="West Bengal",1,0))
model_north_rabi <- lm(v45 ~ log(gdp) + log(tap) + log(beds) + index + v30 + v28 + log(v4) + log(WQI) + dnorth, datarabi)
summary(model_north_rabi)

datarabi <- transform(rabi_data, dwest = ifelse(rabi_data$state=="Rajasthan" | rabi_data$state=="Gujarat" | rabi_data$state=="Goa" | rabi_data$state=="Maharashtra",1,0))
model_west_rabi <- lm(v45 ~ log(gdp) + log(tap) + log(beds) + index + v30 + v28 + log(v4) + log(WQI) + dwest, datarabi)
summary(model_west_rabi)

datarabi <- transform(rabi_data, dnorth_east = ifelse(rabi_data$state == "Assam" | rabi_data$state == "Sikkim" | rabi_data$state =="Nagaland" | rabi_data$state == "Meghalaya" | rabi_data$state == "Manipur"| rabi_data$state == "Mizoram"| rabi_data$state =="Arunachal Pradesh" | rabi_data$state == "Tripura",1,0))
model_north_east_rabi <- lm(v45 ~ log(gdp) + log(tap) + log(beds) + index + v30 + v28 + log(v4) + log(WQI) + dnorth_east, datarabi)
summary(model_north_east_rabi)


datarabi <- transform(rabi_data, deast = ifelse(rabi_data$state == "Bihar" | rabi_data$state == "Orissa" | rabi_data$state =="Jharkhand" | rabi_data$state == "West Bengal" ,1,0))
model_east_rabi <- lm(v45 ~ log(gdp) + log(tap) + log(beds) + index + v30 + v28 + log(v4) + log(WQI) + deast, datarabi)
summary(model_east_rabi)


datarabi <- transform(rabi_data, dcentral = ifelse(rabi_data$state == "Madhya Pradesh" | rabi_data$state == "Chhattisgarh",1,0))
model_central_rabi <- lm(v45 ~ log(gdp) + log(tap) + log(beds) + index + v30 + v28 + log(v4) + log(WQI) + dcentral, datarabi)
summary(model_central_rabi)


model_kharif <- lm(v45 ~ index+ log(gdp) + log(tap) + log(beds) + v30 + v28 +log(v4) + log(WQI), kharif_data)
summary(model_kharif)

datakharif <- transform(kharif_data, dsouth = ifelse(kharif_data$state == "Andhra Pradesh" | kharif_data$state == "Telangana" | kharif_data$state =="Karnataka" | kharif_data$state == "Kerala" | kharif_data$state == "Tamil Nadu",1,0))
model_south_kharif <- lm(v45 ~ index+ log(gdp) + log(tap) + log(beds) + v30 + v28 +log(v4) + log(WQI)+ dsouth, datakharif)
summary(model_south_kharif)

datakharif <- transform(kharif_data, dnorth = ifelse(kharif_data$state=="Bihar" | kharif_data$state=="Orissa" | kharif_data$state=="Jharkhand" | kharif_data$state=="West Bengal",1,0))
model_north_kharif <- lm(v45 ~ index+ log(gdp) + log(tap) + log(beds) + v30 + v28 +log(v4) + log(WQI) + dnorth, datakharif)
summary(model_north_kharif)

datakharif <- transform(kharif_data, dwest = ifelse(kharif_data$state=="Rajasthan" | kharif_data$state=="Gujarat" | kharif_data$state=="Goa" | kharif_data$state=="Maharashtra",1,0))
model_west_kharif <- lm(v45 ~ index+ log(gdp) + log(tap) + log(beds) + v30 + v28 +log(v4) + log(WQI)  + dwest, datakharif)
summary(model_west_kharif)

datakharif <- transform(kharif_data, dnorth_east = ifelse(kharif_data$state == "Assam" | kharif_data$state == "Sikkim" | kharif_data$state =="Nagaland" | kharif_data$state == "Meghalaya" | kharif_data$state == "Manipur"| kharif_data$state == "Mizoram"| kharif_data$state =="Arunachal Pradesh" | kharif_data$state == "Tripura",1,0))
model_north_east_kharif <- lm(v45 ~ index+ log(gdp) + log(tap) + log(beds) + v30 + v28 +log(v4) + log(WQI) + dnorth_east, datakharif)
summary(model_north_east_kharif)


datakharif <- transform(kharif_data, deast = ifelse(kharif_data$state == "Bihar" | kharif_data$state == "Orissa" | kharif_data$state =="Jharkhand" | kharif_data$state == "West Bengal" ,1,0))
model_east_kharif <- lm(v45 ~ index+ log(gdp) + log(tap) + log(beds) + v30 + v28 +log(v4) + log(WQI) + deast, datakharif)
summary(model_east_kharif)


datakharif <- transform(kharif_data, dcentral = ifelse(kharif_data$state == "Madhya Pradesh" | kharif_data$state == "Chhattisgarh",1,0))
model_central_kharif <- lm(v45 ~ index+ log(gdp) + log(tap) + log(beds) + v30 + v28 +log(v4) + log(WQI)+ dcentral, datakharif)
summary(model_central_kharif)
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#F TEST-------------------------------
anova(model_rabi,model_south_rabi)

anova(model_kharif,model_south_kharif)
#---------------------------------------